import ProfileDetails from "./ProfileDetails";
import ProfileCard from "./ProfileCard";

export { ProfileCard, ProfileDetails };
