import LoginForm from "./LoginForm";
import RegistrationForm from "./RegistrationForm";

export { LoginForm, RegistrationForm };
