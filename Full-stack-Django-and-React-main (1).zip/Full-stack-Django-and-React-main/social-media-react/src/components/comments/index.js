import Comment from "./Comment";
import CreateComment from "./CreateComment";
import UpdateComment from "./UpdateComment";

export { Comment, CreateComment, UpdateComment };
